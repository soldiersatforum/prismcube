#!/bin/sh

/usr/local/sbin/softcamdown
/usr/local/sbin/serverdown
sleep 1

rm /usr/local/bin/*cam* -f
rm /usr/local/bin/wicardd -f
rm /usr/local/bin/gbox -f
rm /usr/local/etc -rf
rm -f /config/post-maruapp/S01recovery
rm /config/pre-maruapp/S40*
rm /config/pre-maruapp/S50*
rm /etc/init.d/cardserve* -f
rm /etc/init.d/softca* -f
rm -R /config/tuxbox/
rm -R /var/lib/softcam
rm -R /var/keys
rm -R /config/keys

sync &
