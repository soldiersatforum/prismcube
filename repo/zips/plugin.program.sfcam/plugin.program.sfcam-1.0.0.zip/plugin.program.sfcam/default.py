# -*- coding: utf-8 -*-
import urllib, sys, os, re, time
import xbmcaddon, xbmcplugin, xbmcgui, xbmc
if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson

# Plugin constants
__addonname__ = "SFcam"
__addonid__   = "plugin.program.sfcam"
__addon__     = xbmcaddon.Addon(id=__addonid__)
__language__  = __addon__.getLocalizedString
__cwd__       = xbmc.translatePath( __addon__.getAddonInfo('path') )
__profile__   = xbmc.translatePath( __addon__.getAddonInfo('profile') )
__icondir__   = os.path.join( __cwd__,'resources','icons' )

# Shared resources
BASE_RESOURCE_PATH = os.path.join( __cwd__, 'resources', 'lib' )
sys.path.append (BASE_RESOURCE_PATH)

AUTO_START = __addon__.getSetting('AutomaticStart')




ACTION_PREVIOUS_MENU		= 10 	#ESC
ACTION_PARENT_DIR		= 92	#Back 	

DIALOG_MAIN_GROUP_ID		= 9000
DIALOG_MIDDLE_IMAGE_ID		= 100
DIALOG_BOTTOM_IMAGE_ID		= 101
DIALOG_LIST_ID			= 102
LABEL_SOFTCAM_ID		= 103
LABEL_CARDSERVER_ID		= 104
# WINDOW SIZE
E_WINDOW_WIDTH			= 1280
E_WINDOW_HEIGHT			= 720
DIALOG_WIDTH			= 500


class SoftcamWindow(xbmcgui.WindowXMLDialog):
	def __init__( self, *args, **kwargs ) :
		xbmcgui.WindowXMLDialog.__init__( self, *args, **kwargs )
		self.mWinId = 0
		self.mCtrlList = None
		self.mIsRunning = False
		self.mCsStatus = False

	def onInit(self):
		self.mCtrlList = self.getControl( DIALOG_LIST_ID )

		print '-------oninit---------------'
		cmd = 'chmod 775 '+os.path.join( __cwd__,'*.sh' )
		print 'cmd=%s' %cmd
		os.system ( cmd )

		self.ShowMainMenu()

	def onAction(self, aAction):
		actionId = aAction.getId( )
		if actionId == ACTION_PREVIOUS_MENU or actionId == ACTION_PARENT_DIR :
			self.close()

 
	def onClick(self, aControlID):
		if aControlID == DIALOG_LIST_ID :
			selectedIndex = self.mCtrlList.getSelectedPosition( )
			self.DoAction( selectedIndex )


	def onFocus(self, aControlID):
		pass


	def CheckRunningStatus( self ) :
		print 'CheckRunningStatus'
		if  os.path.exists( '/var/lib/softcam/running' ) :
			return True
		else :
			return False

	def CheckConfigStatus( self ) :
		print 'CheckConfigStatus'
		if  os.path.exists( '/config/tuxbox' ) :
			return True
		else :
			return False


	def OpenBusyDialog( self ) :
		xbmc.executebuiltin( "ActivateWindow(busydialog)" )


	def CloseBusyDialog( self ) :
		xbmc.executebuiltin( "Dialog.Close(busydialog)" )


	def ShowMainMenu( self ) :
		self.mIsRunning = self.CheckRunningStatus( )
		self.mCsStatus = self.CheckConfigStatus( )

		print 'isrunning=%d' %self.mIsRunning
		print 'configstatus=%d' %self.mCsStatus

		menuList = []

		if self.mIsRunning  == True :

			menuList.append( "Seleccionar softcam")
			menuList.append( "Seleccionar cardserver")
			menuList.append( "Instalacion")

			softcam = os.readlink('/etc/init.d/softcam')
			loc = softcam.rfind( '.' )
			print '---------loc=%d' %loc
			if loc > 0 :
				self.getControl( LABEL_SOFTCAM_ID ).setLabel( "SOFTCAM : %s" %softcam[loc+1:] )
				os.system('echo %s > /config/softcam' %softcam[loc+1:] )
			else :
				self.getControl( LABEL_SOFTCAM_ID ).setLabel( "")

			cardserver = os.readlink('/etc/init.d/cardserver')
			loc = cardserver.rfind( '.' )
			locate = cardserver.rfind( 'cardserver.' )

			if loc > 0 :
				self.getControl( LABEL_CARDSERVER_ID ).setLabel( "CARDSERVER : %s" %cardserver[loc+1:] )
				os.system('echo %s > /config/cardserver' %cardserver[locate+11:] )
			else :
				self.getControl( LABEL_CARDSERVER_ID ).setLabel( "")
		else :
			if self.mCsStatus == False:
				menuList.append( "Instalar configuration por defecto")
				menuList.append( "Eliminar configuracion instalada")
			else:
				menuList.append( "Ultima configuracion usada")
				menuList.append( "Eliminar configuracion instalada")


			self.getControl( LABEL_SOFTCAM_ID ).setLabel( "" )
			self.getControl( LABEL_CARDSERVER_ID ).setLabel( "" )			

		self.mCtrlList.addItems( menuList )

	

	def DoAction( self, aSelectedIndex ) :
		if self.mIsRunning  == True :

			softcamList = []
			cardserverdefaultList = []
			cardserverdeList = []
			cardserveratList = []
			cardservernlList = []
			cardserverplList = []
			cardserverchList = []
			cardserveritList = []
			cardserverczskList = []
			
			client = 0
			
			for root,dirs,files in os.walk("/etc/init.d/" ):
				for file in files :
					if (file.find('softcam.') != -1) :
						softcamList.append(file[8:])
					if (file.find('cardserver.default.') != -1):
						cardserverdefaultList.append(file[19:])
					if (file.find('cardserver.de.') != -1):
						cardserverdeList.append(file[14:])
					if (file.find('cardserver.at.') != -1):
						cardserveratList.append(file[14:])
					if (file.find('cardserver.nl.') != -1):
						cardservernlList.append(file[14:])
					if (file.find('cardserver.it.') != -1):
						cardserveritList.append(file[14:])
					if (file.find('cardserver.pl.') != -1):
						cardserverplList.append(file[14:])
					if (file.find('cardserver.ch.') != -1):
						cardserverchList.append(file[14:])
					if (file.find('cardserver.czsk.') != -1):
						cardserverczskList.append(file[16:])
		
			if aSelectedIndex == 40 :
				self.OpenBusyDialog()			
				cmd = os.path.join( __cwd__,'stop.sh' )
				print 'cmd=%s' %cmd
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				
			elif aSelectedIndex == 50 :
				self.OpenBusyDialog()
				cmd = os.path.join( __cwd__,'remove.sh' )
				print 'cmd=%s' %cmd			
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				
			elif aSelectedIndex == 60 :
				self.OpenBusyDialog()
				cmd = os.path.join( __cwd__,'restart.sh' )
				print 'cmd=%s' %cmd			
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				xbmcgui.Dialog().ok( 'Reiniciar Servicios', __language__(0).encode('utf8'), __language__(30005).encode('utf8'), __language__(30006).encode('utf8') )
				
			elif aSelectedIndex == 0 :
				selectSoftcam = xbmcgui.Dialog( ).select(  'Selecciona Softcam',softcamList  )
	                    	if selectSoftcam >= 0 :
					self.OpenBusyDialog()	                    	
					sel=softcamList[selectSoftcam]
					cmd=sel
					os.system("ln -sf /etc/init.d/softcam."+cmd+" /etc/init.d/softcam")
	                    		cmd = os.path.join( __cwd__,'restart.sh' )
					os.system( cmd )
					self.ShowMainMenu()
					self.CloseBusyDialog()
					
				else:
					return
			elif aSelectedIndex == 1 :
				selectMarket = xbmcgui.Dialog( ).select(  'Selecciona Cardserver',  [ 'Ninguno','Normal', 'Oscam', 'AT market','IT market','NL market','PL market','CH market', 'SK/CZ market' ]  )
				if selectMarket < 0 :
					return
				if selectMarket == 0:
	                        	os.system("ln -sf /etc/init.d/cardserver.None /etc/init.d/cardserver")
					os.system("ln -sf /etc/init.d/softcam.Ninguna /etc/init.d/softcam")
				if selectMarket == 1:
					try:
						selectcardserverDefault = xbmcgui.Dialog( ).select( 'Select Cardserver default', cardserverdefaultList)
						if selectcardserverDefault >= 0:
		    		                	sel=cardserverdefaultList[selectcardserverDefault]
							cmd=sel
							os.system("ln -sf /etc/init.d/cardserver.default."+cmd+" /etc/init.d/cardserver")
						else:
							return
					except:
						pass
				if selectMarket == 2:
					try:
						selectcardserverDE = xbmcgui.Dialog( ).select( 'Selecciona Configuracion Oscam', cardserverdeList)
						if selectcardserverDE >= 0:
		    		                	sel=cardserverdeList[selectcardserverDE]
							if (sel.find('-mgcamd') != -1):
								client=1
							cmd=sel
							os.system("ln -sf /etc/init.d/cardserver.de."+cmd+" /etc/init.d/cardserver")
						else:
	    						return
					except:
						pass
				if selectMarket == 3 :
					try:				
						selectcardserverAT = xbmcgui.Dialog( ).select( 'Select Cardserver AT Market', cardserveratList)
	                        		if selectcardserverAT >= 0:
							sel=cardserveratList[selectcardserverAT]
							if (sel.find('-mgcamd') != -1):
								client=1
							cmd=sel
							os.system("ln -sf /etc/init.d/cardserver.at."+cmd+" /etc/init.d/cardserver")
						else:
							return
					except:
						pass
				if selectMarket == 4:
					try:	
						selectcardserverIT = xbmcgui.Dialog( ).select( 'Select Cardserver IT Market', cardserveritList)
						if selectcardserverIT >= 0:
		    		                	sel=cardserveritList[selectcardserverIT]
							if (sel.find('-mgcamd') != -1):
								client=1
							cmd=sel
							os.system("ln -sf /etc/init.d/cardserver.it."+cmd+" /etc/init.d/cardserver")
						else :
							return
					except:
						pass
				if selectMarket == 5:
					try:
						selectcardserverNL = xbmcgui.Dialog( ).select( 'Select Cardserver NL Market', cardservernlList)
						if selectcardserverNL >= 0:
		    		                	sel=cardservernlList[selectcardserverNL]
							if (sel.find('-mgcamd') != -1):
								client=1
							cmd=sel
							os.system("ln -sf /etc/init.d/cardserver.nl."+cmd+" /etc/init.d/cardserver")
						else :
							return
					except:
						pass
				if selectMarket == 6:
					try:
						selectcardserverPL = xbmcgui.Dialog( ).select( 'Select Cardserver PL Market', cardserverplList)
						if selectcardserverPL >= 0 :
		            		        	sel=cardserverplList[selectcardserverPL]
							if (sel.find('-mgcamd') != -1):
								client=1
							cmd=sel
							os.system("ln -sf /etc/init.d/cardserver.pl."+cmd+" /etc/init.d/cardserver")
						else :
							return
					except:
						pass
				if selectMarket == 7:
					try:
						selectcardserverCH = xbmcgui.Dialog( ).select( 'Select Cardserver CH Market', cardserverchList)
						if selectcardserverCH >= 0 :
	        		                	sel=cardserverchList[selectcardserverCH]
							if (sel.find('-mgcamd') != -1):
								client=1
							cmd=sel
							os.system("ln -sf /etc/init.d/cardserver.ch."+cmd+" /etc/init.d/cardserver")
						else :
							return
					except:
						pass
				if selectMarket == 8:
					try:
						selectcardserverCZSK = xbmcgui.Dialog( ).select( 'Select Cardserver CZSK Market', cardserverczskList)
						if selectcardserverCZSK >= 0 :
		                    			sel=cardserverczskList[selectcardserverCZSK]
							if (sel.find('-mgcamd') != -1):
								client=1
							cmd=sel
							os.system("ln -sf /etc/init.d/cardserver.czsk."+cmd+" /etc/init.d/cardserver")
						else :
							return
					except:
						pass
				if client == 1 :
					os.system("ln -sf /etc/init.d/softcam.mgcamd /etc/init.d/softcam")
				else:
					os.system("ln -sf /etc/init.d/softcam.Ninguna /etc/init.d/softcam")

				self.OpenBusyDialog()
		        	cmd = os.path.join( __cwd__,'restart.sh' )
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				xbmcgui.Dialog().ok( 'Iniciar Servicios', __language__(0).encode('utf8'), __language__(30010).encode('utf8'), __language__(30011).encode('utf8') )

# prueba mia


			elif aSelectedIndex == 2 :
				selectInstala = xbmcgui.Dialog( ).select(  'Configuracion',  [ 'Reiniciar', 'Iniciar', 'Parar', 'Borrar' ]  )

			if selectInstala == 0 :
				self.OpenBusyDialog()
				cmd = os.path.join( __cwd__,'restart.sh' )
				print 'cmd=%s' %cmd			
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				xbmcgui.Dialog().ok( 'Reiniciar Servicios', __language__(0).encode('utf8'), __language__(30005).encode('utf8'), __language__(30006).encode('utf8') )


			if selectInstala == 1 :
				self.OpenBusyDialog()
				cmd = os.path.join( __cwd__,'start.sh' )
				print 'cmd=%s' %cmd			
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				xbmcgui.Dialog().ok( 'Iniciar Servicios', __language__(0).encode('utf8'), __language__(30005).encode('utf8'), __language__(30007).encode('utf8') )


			if selectInstala == 2 :
				self.OpenBusyDialog()			
				cmd = os.path.join( __cwd__,'stop.sh' )
				print 'cmd=%s' %cmd
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				xbmcgui.Dialog().ok( 'Parar Servicios', __language__(0).encode('utf8'), __language__(30005).encode('utf8'), __language__(30008).encode('utf8') )

			if selectInstala == 3 :
				self.OpenBusyDialog()
				cmd = os.path.join( __cwd__,'remove.sh' )
				print 'cmd=%s' %cmd			
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				xbmcgui.Dialog().ok( 'Borrando Datos', __language__(0).encode('utf8'), __language__(30005).encode('utf8'), __language__(30009).encode('utf8') )
				
			if selectInstala == 4 :
				self.OpenBusyDialog()
				os.system('/usr/local/sbin/reload.sh' )
				print 'cmd=%s' %cmd			
				os.system( cmd )
				self.ShowMainMenu()
				self.CloseBusyDialog()
				xbmcgui.Dialog().ok( 'SoftcamKey update' , __language__(30003).encode('utf8') )


		else :
			self.OpenBusyDialog()		
			if aSelectedIndex == 0 :
				if self.mCsStatus  == False :
					cmd = os.path.join( __cwd__,'instalar.sh' )
					print 'cmd=%s' %cmd			
			        else:
					cmd = os.path.join( __cwd__,'recovery.sh' )
					print 'cmd=%s' %cmd			
				os.system( cmd )
			elif aSelectedIndex == 1 :
				cmd = os.path.join( __cwd__,'remove.sh' )
				print 'cmd=%s' %cmd			
				os.system(  cmd )		

			self.ShowMainMenu()
			self.CloseBusyDialog()


"""
def EnableSPOFTCAM( aEnable ) :
	if aEnable == True :
		print '---------- Iniciar --------------' 
		ret = xbmcgui.Dialog().ok( __addonname__ , __language__(30001).encode('utf8') )
		
	else :
		print '---------- Parar ---------------'
		ret = xbmcgui.Dialog().ok( __addonname__ , __language__(30002).encode('utf8') )
"""

if __name__ == '__main__' :
	print 'SOFTCAM TEST'
	window = SoftcamWindow( "SoftcamWindow.xml", __cwd__ )
	window.doModal( )
	del window
	xbmc.executebuiltin( 'ActivateWindow(Programs,root)' )			

