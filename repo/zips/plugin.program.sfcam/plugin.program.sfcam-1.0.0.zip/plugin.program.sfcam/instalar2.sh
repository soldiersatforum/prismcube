#!/bin/sh

ADDON_DIR=/mnt/hdd0/program/.xbmc/addons/plugin.program.softcam

	
if [ ! -d /var/lib/softcam ]; then
	echo "no exist spoftcam"
	mkdir /var/lib/softcam -p
	touch /var/lib/softcam/running
	cd /
	unzip -o $ADDON_DIR/interface.zip
	unzip -o $ADDON_DIR/config.zip
	touch /etc/.secondboot
	chmod 777 /etc/init.d/cardserver.*
	chmod 777 /etc/init.d/softcam.*
	chmod 777 /usr/local/bin/*cam*
	chmod 777 /usr/local/bin/gbox
	chmod 777 /usr/local/bin/wicardd
	chmod 777 /usr/local/sbin/*
	chmod 777 /app/factory.sh

	ln -s /config/keys /var/keys
	ln -s /etc/init.d/softcam.Ninguno /etc/init.d/softcam
	ln -s /etc/init.d/cardserver.None /etc/init.d/cardserver
	ln -s /etc/init.d/softcam /config/pre-maruapp/S50softcam
	ln -s /etc/init.d/cardserver /config/pre-maruapp/S40cardserver
        chmod 777 /config/post-maruapp/S01recovery
	depmod -a
	
fi

/sbin/modprobe ftdi_sio
touch /var/lib/softcam/running
/usr/local/sbin/softcamdown
/usr/local/sbin/serverdown
/etc/init.d/cardserver start
sleep 5
/etc/init.d/softcam start

exit 0

