#!/bin/sh

/usr/local/sbin/softcamdown
/usr/local/sbin/serverdown
/etc/init.d/cardserver start
sleep 10
/etc/init.d/softcam start

exit 0


