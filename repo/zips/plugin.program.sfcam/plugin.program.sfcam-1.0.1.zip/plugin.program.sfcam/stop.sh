#!/bin/sh

/usr/local/sbin/softcamdown
/usr/local/sbin/serverdown
/etc/init.d/cardserver stop
sleep 10
/etc/init.d/softcam stop

exit 0

